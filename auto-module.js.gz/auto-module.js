/* Delivery Pro · Módulo Auto multi-vehículo
 * Datos aislados bajo APP_DATA.autos; nunca modifica APP_DATA.moto ni DB.
 * Los borrados son archivados (soft delete) para proteger el historial.
 */
(function () {
  'use strict';

  const CATALOG = {
    'Motor': ['Aceite de motor','Filtro de aceite','Filtro de aire','Filtro de combustible','Bujías','Bobinas','Correa de distribución','Cadena de distribución','Tensor de distribución','Bomba de agua','Bomba de aceite','Retenes de motor','Juntas','Empaquetadura de tapa de cilindros','Reparación de motor','Limpieza de inyectores','Inyectores','Sensor de oxígeno','Sensor de temperatura','Termostato','Radiador','Mangueras de refrigeración','Refrigerante','Electroventilador','Soportes de motor','Otros'],
    'Caja y transmisión': ['Aceite de caja','Filtro de caja automática','Embrague','Disco de embrague','Placa de embrague','Crapodina','Cilindro maestro','Cilindro auxiliar','Semiejes','Homocinéticas','Retenes de caja','Diferencial','Soportes de caja','Otros'],
    'Frenos': ['Pastillas delanteras','Pastillas traseras','Discos de freno','Tambores','Zapatas','Cilindros de rueda','Bomba de freno','Líquido de frenos','Mangueras de freno','Cálipers','Servo de freno','ABS y sensores','Otros'],
    'Suspensión y dirección': ['Amortiguadores delanteros','Amortiguadores traseros','Espirales','Cazoletas','Bujes','Parrillas','Rótulas','Extremos de dirección','Axiales','Cremallera','Bomba hidráulica','Líquido de dirección','Rodamientos','Mazas de rueda','Barra estabilizadora','Otros'],
    'Sistema eléctrico': ['Batería','Alternador','Motor de arranque','Correas auxiliares','Fusibles','Relés','Cableado','Luces delanteras','Luces traseras','Faros','Sensores','Módulos electrónicos','Otros'],
    'Aire acondicionado': ['Carga de gas refrigerante','Compresor','Embrague del compresor','Condensador','Evaporador','Filtro de cabina','Válvula de expansión','Presostato','Electroventilador','Mangueras','Reparación de fugas','Otros'],
    'Neumáticos y ruedas': ['Neumático delantero izquierdo','Neumático delantero derecho','Neumático trasero izquierdo','Neumático trasero derecho','Neumático de auxilio','Rotación','Alineación','Balanceo','Reparación de cubierta','Válvulas','Llantas','Rodamientos','Otros'],
    'Carrocería y exterior': ['Paragolpes','Guardabarros','Capó','Puertas','Espejos','Parabrisas','Vidrios','Limpiaparabrisas','Chapa y pintura','Cerraduras','Otros'],
    'Interior': ['Asientos','Tapizados','Cinturones de seguridad','Tablero','Aireadores','Levantavidrios','Cerraduras internas','Alfombras','Otros'],
    'Escape y combustible': ['Escape','Silenciador','Catalizador','Sonda lambda','Bomba de combustible','Filtro de combustible','Tanque','Mangueras de combustible','Otros'],
    'Mantenimiento general': ['Lavado de motor','Limpieza de inyectores','Limpieza de radiador','Cambio de refrigerante','Cambio de líquido hidráulico','Cambio de líquido de frenos','Revisión general','Inspección preventiva','Otros'],
    'Documentación y controles': ['Inspección técnica','Seguro','Habilitación','Registro de vencimiento','Otros']
  };
  const CATEGORIES = Object.keys(CATALOG);
  const fmtMoney = n => 'Gs. ' + Math.round(Number(n) || 0).toLocaleString('es-PY');
  const fmtNum = n => Math.round(Number(n) || 0).toLocaleString('es-PY');
  const today = () => { const d = new Date(); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); };
  const uid = () => (window.crypto && crypto.randomUUID ? crypto.randomUUID() : 'auto-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10));
  const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const safeDate = value => value ? esc(value.split('-').reverse().join('/')) : '—';
  const num = value => { const n = Number(String(value == null ? '' : value).replace(/[^\d.-]/g,'')); return Number.isFinite(n) && n >= 0 ? n : 0; };
  const css = `
    .dp-auto-hidden{display:none!important}.dp-auto-head{display:flex;justify-content:space-between;align-items:flex-start;gap:10px;margin-bottom:14px}
    .dp-auto-head .sec-title{font-size:22px}.dp-auto-panel{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:14px;margin-bottom:12px}
    .dp-auto-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin-bottom:12px}.dp-auto-stat{background:var(--bg2);border:1px solid var(--border);border-radius:13px;padding:12px;min-width:0}
    .dp-auto-stat small{display:block;color:var(--text3);font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px}.dp-auto-stat b{font-family:var(--ff-display);font-size:17px;overflow-wrap:anywhere}
    .dp-auto-row{display:flex;align-items:center;justify-content:space-between;gap:10px}.dp-auto-muted{color:var(--text3);font-size:12px;line-height:1.5}
    .dp-auto-select,.dp-auto-input,.dp-auto-textarea{width:100%;background:var(--bg3);border:1px solid var(--border-hi);border-radius:11px;color:var(--text);font:14px var(--ff-body);padding:12px;outline:none;min-width:0}
    .dp-auto-select:focus,.dp-auto-input:focus,.dp-auto-textarea:focus{border-color:var(--gold)}.dp-auto-textarea{min-height:76px;resize:vertical}
    .dp-auto-label{display:block;color:var(--text3);font-size:10px;text-transform:uppercase;letter-spacing:.06em;font-weight:700;margin:0 0 6px}.dp-auto-field{min-width:0;margin-bottom:11px}
    .dp-auto-fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.dp-auto-wide{grid-column:1/-1}
    .dp-auto-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}.dp-auto-actions .btn{flex:1 1 130px}
    .dp-auto-section-title{font:800 15px var(--ff-display);margin:0 0 10px;color:var(--text)}.dp-auto-record{background:var(--bg2);border:1px solid var(--border);border-radius:13px;padding:12px;margin-bottom:9px}
    .dp-auto-record-top{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}.dp-auto-record-title{font-weight:800;font-size:14px;line-height:1.35;overflow-wrap:anywhere}
    .dp-auto-record-meta{font-size:11px;color:var(--text3);line-height:1.6;margin-top:4px}.dp-auto-cost{font:800 15px var(--ff-display);color:var(--green);white-space:nowrap}
    .dp-auto-chip{display:inline-flex;padding:4px 8px;border-radius:99px;background:var(--gold-dim);color:var(--gold);font-size:10px;font-weight:800;margin:7px 4px 0 0}
    .dp-auto-chip.red{background:var(--red-dim);color:var(--red)}.dp-auto-chip.green{background:var(--green-dim);color:var(--green)}.dp-auto-chip.blue{background:var(--blue-dim);color:var(--blue)}
    .dp-auto-alert{padding:11px 12px;border-radius:12px;background:var(--gold-dim);border:1px solid rgba(245,166,35,.24);margin:0 0 8px;font-size:12px;line-height:1.5}.dp-auto-alert.red{background:var(--red-dim);border-color:rgba(255,107,107,.25)}
    .dp-auto-empty{text-align:center;padding:22px 12px;color:var(--text3);font-size:13px;line-height:1.6}.dp-auto-filter{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px}
    .dp-auto-filter .wide{grid-column:1/-1}.dp-auto-form-title{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:12px}.dp-auto-form-title b{font:800 16px var(--ff-display)}
    .dp-auto-hint{font-size:11px;color:var(--text3);line-height:1.5;margin-top:4px}.dp-auto-total{padding:12px;border-radius:12px;background:var(--green-dim);border:1px solid rgba(45,212,164,.2);display:flex;justify-content:space-between;align-items:center;font-weight:800;margin:10px 0}
    .dp-auto-total strong{color:var(--green);font:800 18px var(--ff-display)}.dp-auto-smallbtn{background:transparent;border:1px solid var(--border-hi);color:var(--text2);border-radius:9px;padding:7px 9px;font-size:11px;font-weight:700}
    .dp-auto-smallbtn.danger{color:var(--red);border-color:rgba(255,107,107,.3)}.dp-auto-vehicle-name{font:800 18px var(--ff-display);line-height:1.25}
    @media(max-width:380px){.dp-auto-fields,.dp-auto-filter{grid-template-columns:1fr}.dp-auto-wide,.dp-auto-filter .wide{grid-column:auto}.dp-auto-grid{gap:7px}.dp-auto-stat{padding:10px}.dp-auto-stat b{font-size:15px}}
  `;
  let editingVehicleId = null, editingRecordId = null, lastVisit = null;
  let filters = {term:'',category:'',from:'',to:''};

  function ensureData(){
    if(!APP_DATA.autos || typeof APP_DATA.autos!=='object') APP_DATA.autos={schemaVersion:1,selectedVehicleId:null,vehicles:[],maintenance:[]};
    const a=APP_DATA.autos;
    if(!Array.isArray(a.vehicles)) a.vehicles=[];
    if(!Array.isArray(a.maintenance)) a.maintenance=[];
    if(!a.schemaVersion) a.schemaVersion=1;
    return a;
  }
  function mergeRecords(a,b){
    const map=new Map();
    [...(Array.isArray(a)?a:[]),...(Array.isArray(b)?b:[])].forEach(item=>{
      if(!item||!item.id)return;
      const old=map.get(item.id), t1=old&&old.updatedAt?Date.parse(old.updatedAt)||0:0, t2=item.updatedAt?Date.parse(item.updatedAt)||0:0;
      if(!old||t2>=t1)map.set(item.id,item);
    });
    return [...map.values()];
  }
  function mergeAutoData(a,b){
    if(!a&&!b)return {schemaVersion:1,selectedVehicleId:null,vehicles:[],maintenance:[]};
    a=a||{};b=b||{};
    const vehicles=mergeRecords(a.vehicles,b.vehicles), maintenance=mergeRecords(a.maintenance,b.maintenance), live=vehicles.filter(v=>!v.deletedAt);
    const selected=[a.selectedVehicleId,b.selectedVehicleId].find(id=>id&&live.some(v=>v.id===id))||(live[0]&&live[0].id)||null;
    return {...b,...a,schemaVersion:1,vehicles,maintenance,selectedVehicleId:selected};
  }
  // Une copias del teléfono y servidor por ID; los registros archivados se conservan.
  if(typeof window.combinarDatos==='function'&&!window.combinarDatos.__autoMerge){
    const original=window.combinarDatos;
    const wrapped=function(base,otro){const merged=original(base,otro);if(merged&&(base&&base.autos||otro&&otro.autos))merged.autos=mergeAutoData(base&&base.autos,otro&&otro.autos);return merged;};
    wrapped.__autoMerge=true;window.combinarDatos=wrapped;
  }
  function inject(){
    if(!document.getElementById('dp-auto-style')){const st=document.createElement('style');st.id='dp-auto-style';st.textContent=css;document.head.appendChild(st);}
    const grid=document.querySelector('#modal-mas .mas-grid');
    if(grid&&!document.getElementById('mas-auto')){
      const moto=Array.from(grid.querySelectorAll('.mas-item')).find(x=>x.textContent.toLowerCase().includes('moto')&&!x.textContent.toLowerCase().includes('gastos'));
      const btn=document.createElement('button');btn.type='button';btn.id='mas-auto';btn.className='mas-item';btn.innerHTML='<span class="mi">🚘</span>Auto';btn.addEventListener('click',open);
      if(moto)moto.insertAdjacentElement('afterend',btn);else grid.appendChild(btn);
    }
    const area=document.querySelector('.pages-area');
    if(area&&!document.getElementById('page-auto')){const page=document.createElement('section');page.className='page';page.id='page-auto';page.innerHTML='<div id="dp-auto-content"></div>';area.appendChild(page);}
  }
  function open(){closeModal('modal-mas');ensureData();showPage('auto');render();}
  function activeVehicle(){const a=ensureData();let v=a.vehicles.find(x=>x.id===a.selectedVehicleId);if(!v)v=a.vehicles.find(x=>!x.deletedAt)||a.vehicles[0]||null;if(v)a.selectedVehicleId=v.id;return v;}
  function vehiclesForSelect(a){return a.vehicles.slice().sort((x,y)=>(x.deletedAt?1:0)-(y.deletedAt?1:0)||String(x.make||'').localeCompare(String(y.make||'')));}
  function recordsFor(id){return ensureData().maintenance.filter(x=>x.vehicleId===id&&!x.deletedAt).sort((a,b)=>(b.date||'').localeCompare(a.date||'')||(Number(b.km)||0)-(Number(a.km)||0));}
  function totalCost(rows){return rows.reduce((s,r)=>s+(Number(r.totalCost)||0),0);}
  function statusOf(r,v){const kd=Number(r.nextKm)||0,dd=r.nextDate||'',lateKm=kd>0&&Number(v.currentKm||0)>=kd,lateDate=dd&&dd<=today(),soonKm=kd>0&&Number(v.currentKm||0)<kd&&kd-Number(v.currentKm||0)<=500,soonDate=dd&&!lateDate&&(Date.parse(dd+'T00:00:00')-Date.now())<=30*86400000;return{late:!!(lateKm||lateDate),soon:!!(soonKm||soonDate),kmDue:kd,dateDue:dd,remaining:kd>0?kd-Number(v.currentKm||0):null};}
  function saveState(message){APP_DATA.autos=ensureData();save();if(typeof showToast==='function')showToast(message||(typeof hasPending==='function'&&hasPending()?'Guardado en el teléfono; pendiente de sincronizar':'Registro guardado'));}
  function render(){
    inject();const root=document.getElementById('dp-auto-content');if(!root)return;const a=ensureData(),v=activeVehicle(),vs=vehiclesForSelect(a);
    if(!a.vehicles.some(x=>!x.deletedAt)){
      root.innerHTML=`<div class="dp-auto-head"><div><div class="sec-title">Control del auto</div><div class="sec-sub">Historial técnico y de mantenimiento</div></div></div><div class="dp-auto-panel"><div class="dp-auto-empty"><div style="font-size:38px;margin-bottom:8px">🚘</div><b style="color:var(--text);font-size:16px">Todavía no hay vehículos registrados</b><br>Agregá tu primer auto para comenzar a registrar cambios, reparaciones, kilometraje y gastos.</div><button class="btn btn-gold btn-full" onclick="dpAuto.nuevoVehiculo()">+ Registrar mi primer vehículo</button></div><div id="dpAutoVehicleForm" class="dp-auto-panel dp-auto-hidden"></div><div id="dpAutoMaintenanceForm" class="dp-auto-panel dp-auto-hidden"></div>`;return;
    }
    const rows=recordsFor(v.id),total=totalCost(rows),alerts=rows.map(r=>({r,s:statusOf(r,v)})).filter(x=>x.s.late||x.s.soon).sort((x,y)=>(x.s.late===y.s.late?0:x.s.late?-1:1));
    const options=vs.map(x=>`<option value="${esc(x.id)}" ${x.id===v.id?'selected':''}>${esc([x.make,x.model,x.year].filter(Boolean).join(' '))}${x.plate?' · '+esc(x.plate):''}${x.deletedAt?' (Archivado)':''}</option>`).join('');
    root.innerHTML=`
      <div class="dp-auto-head"><div><div class="sec-title">Control del auto</div><div class="sec-sub">Mantenimiento, reparaciones y costos por vehículo</div></div><button class="btn btn-ghost" onclick="dpAuto.nuevoVehiculo()" style="padding:9px 12px;font-size:12px">+ Vehículo</button></div>
      <div class="dp-auto-panel"><label class="dp-auto-label" for="dpAutoVehicleSelect">Vehículo seleccionado</label><select id="dpAutoVehicleSelect" class="dp-auto-select" onchange="dpAuto.seleccionar(this.value)">${options}</select>
        <div class="dp-auto-row" style="margin-top:12px;align-items:flex-start"><div style="min-width:0"><div class="dp-auto-vehicle-name">${esc([v.make,v.model].filter(Boolean).join(' ')||'Vehículo sin nombre')}</div><div class="dp-auto-muted">${esc([v.year,v.plate?'Matrícula '+v.plate:'',v.color].filter(Boolean).join(' · ')||'Completá los datos del vehículo')}</div></div><span class="dp-auto-chip ${v.deletedAt?'red':'green'}">${v.deletedAt?'ARCHIVADO':'ACTIVO'}</span></div>
        <div class="dp-auto-grid" style="margin-top:13px"><div class="dp-auto-stat"><small>Kilometraje actual</small><b>${fmtNum(v.currentKm)} km</b></div><div class="dp-auto-stat"><small>Mantenimientos registrados</small><b>${rows.length}</b></div><div class="dp-auto-stat"><small>Total invertido</small><b style="color:var(--green)">${fmtMoney(total)}</b></div><div class="dp-auto-stat"><small>Próximas alertas</small><b>${alerts.length}</b></div></div>
        <div class="dp-auto-actions"><button class="btn btn-gold" onclick="dpAuto.nuevoMantenimiento()" ${v.deletedAt?'disabled':''}>+ Registrar trabajo</button><button class="btn btn-ghost" onclick="dpAuto.editarVehiculo('${esc(v.id)}')">Editar vehículo</button><button class="btn btn-ghost" onclick="dpAuto.actualizarKm()">Actualizar km</button><button class="btn btn-ghost" onclick="dpAuto.pdf()">Descargar PDF</button><button class="btn btn-ghost" onclick="dpAuto.archivarVehiculo('${esc(v.id)}')">${v.deletedAt?'Reactivar vehículo':'Archivar vehículo'}</button></div>
      </div>
      <div class="dp-auto-panel"><div class="dp-auto-section-title">Alertas y próximos mantenimientos</div>${alerts.length?alerts.map(({r,s})=>`<div class="dp-auto-alert ${s.late?'red':''}"><b>${s.late?'VENCIDO':'PRÓXIMO'} · ${esc(r.item)}</b><div>${s.kmDue?`Objetivo: ${fmtNum(s.kmDue)} km · ${s.remaining<=0?'superado por '+fmtNum(Math.abs(s.remaining))+' km':'faltan '+fmtNum(s.remaining)+' km'}`:''}${s.dateDue?(s.kmDue?' · ':'')+'Fecha: '+safeDate(s.dateDue):''}</div></div>`).join(''):'<div class="dp-auto-muted">No hay alertas configuradas o próximas para este vehículo.</div>'}</div>
      <div id="dpAutoVehicleForm" class="dp-auto-panel dp-auto-hidden"></div><div id="dpAutoMaintenanceForm" class="dp-auto-panel dp-auto-hidden"></div>
      <div class="dp-auto-panel"><div class="dp-auto-row"><div class="dp-auto-section-title" style="margin:0">Historial de trabajos</div><span class="dp-auto-muted">${rows.length} registros</span></div><div class="dp-auto-filter" style="margin-top:12px"><input class="dp-auto-input wide" id="dpAutoSearch" placeholder="Buscar pieza, trabajo o taller" value="${esc(filters.term)}" oninput="dpAuto.filtrar()"><select class="dp-auto-select" id="dpAutoCategory" onchange="dpAuto.filtrar()"><option value="">Todas las categorías</option>${CATEGORIES.map(c=>`<option ${filters.category===c?'selected':''} value="${esc(c)}">${esc(c)}</option>`).join('')}</select><input class="dp-auto-input" id="dpAutoFrom" type="date" aria-label="Desde" value="${esc(filters.from)}" onchange="dpAuto.filtrar()"><input class="dp-auto-input" id="dpAutoTo" type="date" aria-label="Hasta" value="${esc(filters.to)}" onchange="dpAuto.filtrar()"></div><div id="dpAutoHistory"></div></div>
      ${vs.some(x=>x.deletedAt)?'<div class="dp-auto-muted" style="text-align:center;margin:8px 0">Los vehículos archivados se conservan junto con todos sus trabajos. Podés reactivarlos desde el selector.</div>':''}<datalist id="dpAutoCatalog">${CATEGORIES.flatMap(c=>CATALOG[c].map(i=>`<option value="${esc(i)}"></option>`)).join('')}</datalist>`;
    drawHistory();
  }
  function drawHistory(){
    const box=document.getElementById('dpAutoHistory');if(!box)return;const v=activeVehicle();if(!v){box.innerHTML='<div class="dp-auto-empty">Seleccioná un vehículo.</div>';return;}
    const term=(document.getElementById('dpAutoSearch')?.value||filters.term).toLowerCase().trim(),category=document.getElementById('dpAutoCategory')?.value||filters.category,from=document.getElementById('dpAutoFrom')?.value||filters.from,to=document.getElementById('dpAutoTo')?.value||filters.to;
    filters={term,category,from,to};
    const rows=recordsFor(v.id).filter(r=>(!category||r.category===category)&&(!from||r.date>=from)&&(!to||r.date<=to)&&(!term||[r.item,r.description,r.workshop,r.brand,r.reference,r.notes].join(' ').toLowerCase().includes(term)));
    box.innerHTML=rows.length?rows.map(r=>{const s=statusOf(r,v);return `<article class="dp-auto-record"><div class="dp-auto-record-top"><div style="min-width:0"><div class="dp-auto-record-title">${esc(r.item)}</div><div class="dp-auto-record-meta">${esc(r.category)} · ${safeDate(r.date)} · ${fmtNum(r.km)} km${r.workshop?' · '+esc(r.workshop):''}</div></div><div class="dp-auto-cost">${fmtMoney(r.totalCost)}</div></div>${r.description?`<div style="font-size:12px;color:var(--text2);margin-top:8px;line-height:1.5">${esc(r.description)}</div>`:''}<div>${r.brand?`<span class="dp-auto-chip blue">${esc(r.brand)}</span>`:''}${r.nextKm?`<span class="dp-auto-chip ${s.late?'red':s.soon?'':'green'}">Próximo: ${fmtNum(r.nextKm)} km</span>`:''}${r.nextDate?`<span class="dp-auto-chip">Revisar: ${safeDate(r.nextDate)}</span>`:''}</div><div class="dp-auto-actions"><button class="dp-auto-smallbtn" onclick="dpAuto.editarMantenimiento('${esc(r.id)}')">Editar</button><button class="dp-auto-smallbtn danger" onclick="dpAuto.eliminarMantenimiento('${esc(r.id)}')">Eliminar</button></div></article>`;}).join(''):'<div class="dp-auto-empty">No hay registros que coincidan con estos filtros.</div>';
  }
  function renderVehicleForm(vehicle){
    const box=document.getElementById('dpAutoVehicleForm');if(!box)return;const v=vehicle||{};box.classList.remove('dp-auto-hidden');
    box.innerHTML=`<div class="dp-auto-form-title"><b>${v.id?'Editar vehículo':'Registrar vehículo'}</b><button class="dp-auto-smallbtn" onclick="dpAuto.cerrarForm('vehicle')">Cerrar</button></div><form onsubmit="event.preventDefault();dpAuto.guardarVehiculo()"><div class="dp-auto-fields">
      <div class="dp-auto-field"><label class="dp-auto-label">Marca *</label><input class="dp-auto-input" id="avMake" required maxlength="50" value="${esc(v.make||'')}" placeholder="Toyota"></div><div class="dp-auto-field"><label class="dp-auto-label">Modelo *</label><input class="dp-auto-input" id="avModel" required maxlength="60" value="${esc(v.model||'')}" placeholder="Corolla"></div>
      <div class="dp-auto-field"><label class="dp-auto-label">Año</label><input class="dp-auto-input" id="avYear" type="number" min="1950" max="2100" value="${esc(v.year||'')}" placeholder="2015"></div><div class="dp-auto-field"><label class="dp-auto-label">Matrícula</label><input class="dp-auto-input" id="avPlate" maxlength="20" value="${esc(v.plate||'')}" placeholder="ABC 123"></div>
      <div class="dp-auto-field"><label class="dp-auto-label">Color</label><input class="dp-auto-input" id="avColor" maxlength="30" value="${esc(v.color||'')}"></div><div class="dp-auto-field"><label class="dp-auto-label">Combustible</label><select class="dp-auto-select" id="avFuel">${['Nafta','Diésel','Flex','Híbrido','Eléctrico','GLP','Otro'].map(x=>`<option ${v.fuelType===x?'selected':''}>${x}</option>`).join('')}</select></div>
      <div class="dp-auto-field"><label class="dp-auto-label">Versión / motor</label><input class="dp-auto-input" id="avVersion" maxlength="80" value="${esc(v.version||'')}" placeholder="1.8, 2.0, etc."></div><div class="dp-auto-field"><label class="dp-auto-label">N.º de chasis (opcional)</label><input class="dp-auto-input" id="avChassis" maxlength="80" value="${esc(v.chassis||'')}"></div>
      <div class="dp-auto-field"><label class="dp-auto-label">Fecha de adquisición</label><input class="dp-auto-input" id="avAcquired" type="date" value="${esc(v.acquiredAt||'')}"></div><div class="dp-auto-field"><label class="dp-auto-label">Kilometraje actual *</label><input class="dp-auto-input" id="avKm" type="number" min="0" step="1" required value="${esc(v.currentKm??'')}" placeholder="150000"></div>
      <div class="dp-auto-field dp-auto-wide"><label class="dp-auto-label">Observaciones</label><textarea class="dp-auto-textarea" id="avNotes" maxlength="1000">${esc(v.notes||'')}</textarea></div></div><button class="btn btn-gold btn-full" type="submit">${v.id?'Guardar cambios':'Guardar vehículo'}</button></form>`;
    box.scrollIntoView({behavior:'smooth',block:'start'});
  }
  function renderMaintenanceForm(record,prefill){
    const box=document.getElementById('dpAutoMaintenanceForm');if(!box)return;const r=record||{},base=prefill||{};box.classList.remove('dp-auto-hidden');
    box.innerHTML=`<div class="dp-auto-form-title"><b>${r.id?'Editar mantenimiento':'Registrar mantenimiento o reparación'}</b><button class="dp-auto-smallbtn" onclick="dpAuto.cerrarForm('maintenance')">Cerrar</button></div><form onsubmit="event.preventDefault();dpAuto.guardarMantenimiento()"><div class="dp-auto-fields">
      <div class="dp-auto-field"><label class="dp-auto-label">Categoría *</label><select class="dp-auto-select" id="amCategory" required>${CATEGORIES.map(c=>`<option ${r.category===c?'selected':''}>${esc(c)}</option>`).join('')}</select></div><div class="dp-auto-field"><label class="dp-auto-label">Pieza / trabajo *</label><input class="dp-auto-input" id="amItem" list="dpAutoCatalog" required maxlength="100" value="${esc(r.item||'')}" placeholder="Elegí o escribí una pieza"></div>
      <div class="dp-auto-field"><label class="dp-auto-label">Fecha del trabajo *</label><input class="dp-auto-input" id="amDate" type="date" required value="${esc(r.date||base.date||today())}"></div><div class="dp-auto-field"><label class="dp-auto-label">Kilometraje del trabajo *</label><input class="dp-auto-input" id="amKm" type="number" min="0" step="1" required value="${esc(r.km??base.km??activeVehicle()?.currentKm??'')}"></div>
      <div class="dp-auto-field"><label class="dp-auto-label">Marca del repuesto</label><input class="dp-auto-input" id="amBrand" maxlength="60" value="${esc(r.brand||'')}"></div><div class="dp-auto-field"><label class="dp-auto-label">Modelo / referencia</label><input class="dp-auto-input" id="amRef" maxlength="80" value="${esc(r.reference||'')}"></div>
      <div class="dp-auto-field"><label class="dp-auto-label">Cantidad</label><input class="dp-auto-input" id="amQty" type="number" min="0.01" step="0.01" value="${esc(r.quantity??1)}"></div><div class="dp-auto-field"><label class="dp-auto-label">Costo de repuestos (Gs.)</label><input class="dp-auto-input" id="amParts" type="number" min="0" step="1" value="${esc(r.partsCost??0)}" oninput="dpAuto.calcularTotal()"></div>
      <div class="dp-auto-field"><label class="dp-auto-label">Mano de obra (Gs.)</label><input class="dp-auto-input" id="amLabor" type="number" min="0" step="1" value="${esc(r.laborCost??0)}" oninput="dpAuto.calcularTotal()"></div><div class="dp-auto-field"><label class="dp-auto-label">Otros gastos (Gs.)</label><input class="dp-auto-input" id="amOther" type="number" min="0" step="1" value="${esc(r.otherCost??0)}" oninput="dpAuto.calcularTotal()"></div>
      <div class="dp-auto-field dp-auto-wide"><label class="dp-auto-label">Taller / mecánico</label><input class="dp-auto-input" id="amWorkshop" maxlength="100" value="${esc(r.workshop||base.workshop||'')}"></div><div class="dp-auto-field dp-auto-wide"><label class="dp-auto-label">Descripción del trabajo realizado</label><textarea class="dp-auto-textarea" id="amDescription" maxlength="1500">${esc(r.description||'')}</textarea></div>
      <div class="dp-auto-field"><label class="dp-auto-label">Próximo cambio a los km</label><input class="dp-auto-input" id="amNextKm" type="number" min="0" step="1" value="${esc(r.nextKm||'')}" placeholder="Ej. 155000"><div class="dp-auto-hint">Kilometraje objetivo absoluto, no intervalo.</div></div><div class="dp-auto-field"><label class="dp-auto-label">Próxima revisión por fecha</label><input class="dp-auto-input" id="amNextDate" type="date" value="${esc(r.nextDate||'')}"></div>
      <div class="dp-auto-field dp-auto-wide"><label class="dp-auto-label">Garantía del repuesto o trabajo</label><input class="dp-auto-input" id="amWarranty" maxlength="120" value="${esc(r.warranty||'')}" placeholder="Ej. 3 meses / 5.000 km"></div><div class="dp-auto-field dp-auto-wide"><label class="dp-auto-label">Observaciones</label><textarea class="dp-auto-textarea" id="amNotes" maxlength="1500">${esc(r.notes||'')}</textarea></div></div>
      <div class="dp-auto-total"><span>Costo total</span><strong id="amTotal">${fmtMoney((Number(r.partsCost)||0)+(Number(r.laborCost)||0)+(Number(r.otherCost)||0))}</strong></div><div class="dp-auto-hint">Cada pieza o trabajo se guarda como un registro independiente. Podés agrupar varios trabajos de la misma visita usando «Agregar otro trabajo de esta visita» después de guardar.</div><button class="btn btn-gold btn-full" style="margin-top:12px" type="submit">${r.id?'Guardar cambios':'Guardar mantenimiento'}</button></form>`;
    box.scrollIntoView({behavior:'smooth',block:'start'});
  }
  function nuevoVehiculo(){editingVehicleId=null;renderVehicleForm(null);}
  function editarVehiculo(id){const v=ensureData().vehicles.find(x=>x.id===id);if(v){editingVehicleId=id;renderVehicleForm(v);}}
  function guardarVehiculo(){
    const a=ensureData(),old=editingVehicleId?a.vehicles.find(x=>x.id===editingVehicleId):null,make=document.getElementById('avMake').value.trim(),model=document.getElementById('avModel').value.trim(),kmRaw=document.getElementById('avKm').value,km=num(kmRaw);
    if(!make||!model||!kmRaw.trim()){alert('Completá marca, modelo y kilometraje.');return;}
    const now=new Date().toISOString(),v={...(old||{}),id:old?old.id:uid(),make,model,year:document.getElementById('avYear').value,plate:document.getElementById('avPlate').value.trim().toUpperCase(),color:document.getElementById('avColor').value.trim(),fuelType:document.getElementById('avFuel').value,version:document.getElementById('avVersion').value.trim(),chassis:document.getElementById('avChassis').value.trim(),acquiredAt:document.getElementById('avAcquired').value,currentKm:km,notes:document.getElementById('avNotes').value.trim(),createdAt:old?old.createdAt:now,updatedAt:now};
    if(old)a.vehicles=a.vehicles.map(x=>x.id===old.id?v:x);else{a.vehicles.push(v);a.selectedVehicleId=v.id;}editingVehicleId=null;saveState(old?'Vehículo actualizado':'Vehículo registrado');render();
  }
  function seleccionar(id){const a=ensureData();if(a.vehicles.some(v=>v.id===id)){a.selectedVehicleId=id;filters={term:'',category:'',from:'',to:''};saveState('Vehículo seleccionado');render();}}
  function actualizarKm(){const v=activeVehicle();if(!v)return;const answer=prompt('Ingresá el kilometraje actual del vehículo:',String(v.currentKm||0));if(answer===null)return;if(!/^\d+([.,]\d+)?$/.test(answer.trim())){alert('Ingresá un kilometraje válido.');return;}const km=num(answer);if(km<Number(v.currentKm||0)&&!confirm('El kilometraje ingresado es menor al registrado. ¿Querés corregirlo de todos modos?'))return;v.currentKm=km;v.updatedAt=new Date().toISOString();saveState('Kilometraje actualizado');render();}
  function archivarVehiculo(id){const a=ensureData(),v=a.vehicles.find(x=>x.id===id);if(!v)return;if(v.deletedAt){if(!confirm('¿Reactivar este vehículo?'))return;delete v.deletedAt;}else{if(!confirm('Se archivará el vehículo. Su historial y sus costos se conservarán; no se eliminarán registros. ¿Continuar?'))return;v.deletedAt=new Date().toISOString();}v.updatedAt=new Date().toISOString();if(a.selectedVehicleId===id&&v.deletedAt){const next=a.vehicles.find(x=>x.id!==id&&!x.deletedAt);a.selectedVehicleId=next?next.id:null;}saveState(v.deletedAt?'Vehículo archivado':'Vehículo reactivado');render();}
  function nuevoMantenimiento(){if(!activeVehicle()){nuevoVehiculo();return;}if(activeVehicle().deletedAt){alert('Reactivá el vehículo antes de registrar nuevos trabajos.');return;}editingRecordId=null;lastVisit=null;renderMaintenanceForm(null,null);}
  function agregarOtroTrabajo(){if(!lastVisit)return;editingRecordId=null;renderMaintenanceForm(null,lastVisit);}
  function editarMantenimiento(id){const r=ensureData().maintenance.find(x=>x.id===id&&!x.deletedAt);if(!r)return;ensureData().selectedVehicleId=r.vehicleId;editingRecordId=id;render();renderMaintenanceForm(r,null);}
  function guardarMantenimiento(){
    const a=ensureData(),v=activeVehicle();if(!v)return;const category=document.getElementById('amCategory').value,item=document.getElementById('amItem').value.trim(),date=document.getElementById('amDate').value,kmRaw=document.getElementById('amKm').value,km=num(kmRaw);
    if(!category||!item||!date||kmRaw===''){alert('Completá categoría, pieza, fecha y kilometraje.');return;}
    const parts=num(document.getElementById('amParts').value),labor=num(document.getElementById('amLabor').value),other=num(document.getElementById('amOther').value),old=editingRecordId?a.maintenance.find(x=>x.id===editingRecordId):null,now=new Date().toISOString();
    const visit=(old&&old.visitId)||(lastVisit&&lastVisit.vehicleId===v.id&&lastVisit.date===date&&lastVisit.km===km?lastVisit.id:uid());
    const r={...(old||{}),id:old?old.id:uid(),vehicleId:v.id,visitId:visit,date,km,category,item,description:document.getElementById('amDescription').value.trim(),brand:document.getElementById('amBrand').value.trim(),reference:document.getElementById('amRef').value.trim(),quantity:num(document.getElementById('amQty').value)||1,partsCost:parts,laborCost:labor,otherCost:other,totalCost:parts+labor+other,workshop:document.getElementById('amWorkshop').value.trim(),nextKm:num(document.getElementById('amNextKm').value),nextDate:document.getElementById('amNextDate').value,warranty:document.getElementById('amWarranty').value.trim(),notes:document.getElementById('amNotes').value.trim(),createdAt:old?old.createdAt:now,updatedAt:now};
    if(old)a.maintenance=a.maintenance.map(x=>x.id===old.id?r:x);else a.maintenance.push(r);if(km>Number(v.currentKm||0))v.currentKm=km;v.updatedAt=now;a.selectedVehicleId=v.id;lastVisit={id:visit,vehicleId:v.id,date,km,workshop:r.workshop};editingRecordId=null;saveState(old?'Mantenimiento actualizado':'Mantenimiento registrado');render();
    const panel=document.getElementById('dpAutoMaintenanceForm');if(panel){panel.classList.remove('dp-auto-hidden');panel.innerHTML=`<div class="dp-auto-alert"><b>Trabajo guardado.</b> ${esc(item)} · ${fmtMoney(r.totalCost)}. Para cargar otra pieza de la misma visita, usá el botón de abajo.</div><button class="btn btn-gold btn-full" onclick="dpAuto.agregarOtroTrabajo()">+ Agregar otro trabajo de esta visita</button>`;}
  }
  function eliminarMantenimiento(id){const r=ensureData().maintenance.find(x=>x.id===id);if(!r)return;if(!confirm('¿Marcar este registro como eliminado? Quedará archivado para proteger la sincronización.'))return;r.deletedAt=new Date().toISOString();r.updatedAt=r.deletedAt;saveState('Registro archivado');render();}
  function cerrarForm(which){const box=document.getElementById(which==='vehicle'?'dpAutoVehicleForm':'dpAutoMaintenanceForm');if(box){box.classList.add('dp-auto-hidden');box.innerHTML='';}editingVehicleId=null;editingRecordId=null;}
  function filtrar(){drawHistory();}
  function calcularTotal(){const total=num(document.getElementById('amParts')?.value)+num(document.getElementById('amLabor')?.value)+num(document.getElementById('amOther')?.value),el=document.getElementById('amTotal');if(el)el.textContent=fmtMoney(total);}
  function pdf(){
    const v=activeVehicle();if(!v){alert('Primero registrá un vehículo.');return;}
    const rows=recordsFor(v.id).filter(r=>(!filters.category||r.category===filters.category)&&(!filters.from||r.date>=filters.from)&&(!filters.to||r.date<=filters.to)&&(!filters.term||[r.item,r.description,r.workshop,r.brand,r.reference,r.notes].join(' ').toLowerCase().includes(filters.term.toLowerCase()))),total=totalCost(rows),alerts=rows.map(r=>({r,s:statusOf(r,v)})).filter(x=>x.s.late||x.s.soon),popup=window.open('about:blank','_blank');
    if(!popup){alert('El navegador bloqueó la ventana del informe. Permití las ventanas emergentes para descargar el PDF.');return;}
    const table=rows.map(r=>`<tr><td>${safeDate(r.date)}</td><td>${fmtNum(r.km)} km</td><td>${esc(r.category)}</td><td><b>${esc(r.item)}</b><br><small>${esc(r.description||'')}</small></td><td>${esc(r.brand||'—')}<br><small>${esc(r.reference||'')}</small></td><td>${esc(r.workshop||'—')}</td><td class="num">${fmtMoney(r.partsCost)}</td><td class="num">${fmtMoney(r.laborCost)}</td><td class="num"><b>${fmtMoney(r.totalCost)}</b></td></tr>`).join('');
    const filterLabel=[filters.category||'Todas las categorías',filters.from?'Desde '+safeDate(filters.from):'',filters.to?'Hasta '+safeDate(filters.to):'',filters.term?'Búsqueda: '+esc(filters.term):''].filter(Boolean).join(' · ');
    const html=`<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Historial de vehículo - Delivery Pro</title><style>
      *{box-sizing:border-box}body{font:12px Arial,sans-serif;color:#172033;margin:26px}header{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #e6a12a;padding-bottom:14px;margin-bottom:18px}h1{font-size:22px;margin:0 0 5px}h2{font-size:15px;margin:20px 0 9px}.muted{color:#657085;font-size:10px}.brand{font-weight:800;color:#b87910;font-size:14px}.veh{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:16px 0}.tile{border:1px solid #dce1e9;border-radius:8px;padding:9px}.tile small{display:block;color:#687386;font-size:9px;text-transform:uppercase}.tile b{display:block;font-size:13px;margin-top:5px}.sum{font-size:20px;font-weight:800;color:#11845c}table{width:100%;border-collapse:collapse;font-size:9px}th{background:#172033;color:white;text-align:left;padding:8px 6px}td{border-bottom:1px solid #e2e7ef;padding:7px 6px;vertical-align:top}tr:nth-child(even) td{background:#f7f8fa}.num{text-align:right;white-space:nowrap}small{color:#687386;line-height:1.4}.alert{padding:8px 10px;background:#fff4dc;border:1px solid #edce8e;border-radius:7px;margin:5px 0}.actions{margin:0 0 16px;display:flex;gap:8px}.actions button{padding:10px 14px;border:0;border-radius:7px;background:#172033;color:#fff;font-weight:700}.foot{margin-top:20px;border-top:1px solid #dce1e9;padding-top:8px;color:#697386;font-size:9px}@page{size:landscape;margin:12mm}@media print{.actions{display:none}body{margin:0}}</style></head><body>
      <div class="actions"><button onclick="window.print()">Imprimir / Guardar como PDF</button><button onclick="window.close()">Cerrar</button></div><header><div><div class="brand">DELIVERY PRO · CONTROL VEHICULAR</div><h1>Historial técnico del vehículo</h1><div class="muted">Informe generado: ${safeDate(today())} · Paraguay · Importes en guaraníes</div></div><div class="muted">Documento de mantenimiento</div></header>
      <h2>${esc([v.make,v.model,v.year].filter(Boolean).join(' '))}</h2><div class="veh"><div class="tile"><small>Matrícula</small><b>${esc(v.plate||'—')}</b></div><div class="tile"><small>Color / combustible</small><b>${esc([v.color,v.fuelType].filter(Boolean).join(' · ')||'—')}</b></div><div class="tile"><small>Kilometraje actual</small><b>${fmtNum(v.currentKm)} km</b></div><div class="tile"><small>Motor / versión</small><b>${esc(v.version||'—')}</b></div><div class="tile"><small>Chasis</small><b>${esc(v.chassis||'—')}</b></div><div class="tile"><small>Fecha de adquisición</small><b>${safeDate(v.acquiredAt)}</b></div></div>
      <div class="veh"><div class="tile"><small>Trabajos incluidos</small><b>${rows.length}</b></div><div class="tile"><small>Total invertido en este informe</small><b class="sum">${fmtMoney(total)}</b></div><div class="tile"><small>Alertas de mantenimiento</small><b>${alerts.length}</b></div></div>${filterLabel?`<p class="muted">Filtros aplicados: ${filterLabel}</p>`:''}
      <h2>Detalle de mantenimientos y reparaciones</h2><table><thead><tr><th>Fecha</th><th>Km</th><th>Categoría</th><th>Pieza / trabajo</th><th>Marca / referencia</th><th>Taller</th><th>Repuestos</th><th>Mano de obra</th><th>Total</th></tr></thead><tbody>${table||'<tr><td colspan="9">No hay trabajos para los filtros seleccionados.</td></tr>'}</tbody></table>
      ${alerts.length?`<h2>Próximos mantenimientos / vencimientos</h2>${alerts.map(({r,s})=>`<div class="alert"><b>${s.late?'VENCIDO':'PRÓXIMO'}:</b> ${esc(r.item)} · ${s.kmDue?`Objetivo ${fmtNum(s.kmDue)} km`:''} ${s.dateDue?'· Fecha '+safeDate(s.dateDue):''}</div>`).join('')}`:''}${v.notes?`<h2>Observaciones del vehículo</h2><p>${esc(v.notes)}</p>`:''}
      <div class="foot">Este informe contiene los datos registrados por el usuario en Delivery Pro. Los intervalos de mantenimiento y las fechas futuras deben configurarse según las especificaciones del fabricante y las condiciones reales del vehículo.</div><script>window.addEventListener('load',()=>setTimeout(()=>window.print(),350));<\/script></body></html>`;
    popup.document.open();popup.document.write(html);popup.document.close();
  }
  window.dpAuto={open,nuevoVehiculo,editarVehiculo,guardarVehiculo,seleccionar,actualizarKm,archivarVehiculo,nuevoMantenimiento,agregarOtroTrabajo,editarMantenimiento,guardarMantenimiento,eliminarMantenimiento,cerrarForm,filtrar,calcularTotal,pdf};
  inject();if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',inject,{once:true});
})();
